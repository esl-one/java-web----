package beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import db.DbConn;
import md5.MD5_USE;

public class User {
	private String username;
	private String userpwd;
	private String type;
	
public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpwd() {
		return userpwd;
	}

	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}


	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public boolean yanzheng(String username,String userpwd,String type)throws Exception{
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		boolean f=false;
		String sql="select *from log where username=? and password=? and type=?";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			MD5_USE m = new MD5_USE();
			String password = m.MD5(userpwd);
			pst.setString(1, username);
			pst.setString(2, password);
			pst.setString(3, type);
			rs=pst.executeQuery();
			if(rs.next())f=true;
			else f=false;
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
		return f;
	}
	
	



	
}