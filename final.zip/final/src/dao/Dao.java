package dao;

import java.awt.print.Book;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import beans.Books;
import beans.User;
import db.DbConn;

public class Dao {
	public void addUser(User u)throws Exception{
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String sql="insert into log(username,password,type) values(?,?,?)";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, u.getUsername());
			pst.setString(2, u.getUserpwd());
			pst.setString(3, u.getType());
			int n=pst.executeUpdate();
			if(n==0)throw new Exception("注册失败");
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
	}
	
	public static int getPageCount()throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int recordCount = 0,t1 = 0,t2 = 0;
		try{
			conn = DbConn.getDBconnect();
			String sql = "select count(*) from book";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			rs.next();
			recordCount = rs.getInt(1);
			t1 = recordCount%5;
			t2 = recordCount/5;
		}finally{
			DbConn.closeDB(conn, ps, rs);
		}
		return t1 ==0?t2:t2+1;
	}
	
	public List<Books>listBooks(int pageNo)throws Exception{
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int pageSize = 5;
		int startRecno = (pageNo-1)*pageSize;
		ArrayList<Books> bookslist  = new ArrayList<Books>();
		try{
			conn = DbConn.getDBconnect();
			String sql = "select * from book order by bid limit ?,?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, startRecno);
			ps.setInt(2, pageSize);
			rs = ps.executeQuery();
			while(rs.next()){
				Books b = new Books();
				b.setBname(rs.getString(1));
				b.setAuthor(rs.getString(2));
				b.setPrice(rs.getString(3));
				b.setBid(rs.getString(4));
				b.setRemarks(rs.getString(5));
				bookslist.add(b);
			}
		}finally{
			DbConn.closeDB(conn, ps, rs);
		}
		return bookslist;
	}
}
