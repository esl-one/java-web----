package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import beans.Books;
//simport beans.DBConnect;
//import beans.DBConnect;
import beans.Message;
//Simport beans.User;
import db.DbConn;

public class MDAO {

	public void addBook(Books b)throws Exception{
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String sql="insert into Book(bid,bname,author,price,remarks,bnum) values(?,?,?,?,?,?);";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, b.getBid());
			pst.setString(2, b.getBname());
			pst.setString(3, b.getAuthor());
			pst.setString(4, b.getPrice());
			pst.setString(5, b.getRemarks());
			pst.setInt(6, b.getBnum());
			int n=pst.executeUpdate();
			if(n==0)throw new Exception("添加失败");
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
	}
	
	public void deleteBook(String bname)throws Exception {
		
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String sql="delete from Book where bname=?";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, bname);
			int n=pst.executeUpdate();
			if(n==0)throw new Exception("删除失败");
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
	}
	
	public void updateBook(Books b)throws Exception {
		
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String sql="update Book set bid=?,bname=?,author=?, price=?,remarks=?,bnum = ? where bname=?";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, b.getBid());
			pst.setString(2, b.getBname());
			pst.setString(3, b.getAuthor());
			pst.setString(4, b.getPrice());
			pst.setString(5, b.getRemarks());
			pst.setInt(6, b.getBnum());
			pst.setString(7, b.getBname());
			int n=pst.executeUpdate();
			if(n==0)throw new Exception("更改失败");
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
	}
	
	public Books findBook(String bname)throws Exception{
		
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		Books b2=null;
		String sql="select *from Book where bname=?;";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, bname);
			rs=pst.executeQuery();
			if(rs.next()) {
				b2=new Books();
				b2.setBid(rs.getString("bid"));
				b2.setBname(rs.getString(2));
				b2.setAuthor(rs.getString(3));
				b2.setPrice(rs.getString(4));
				b2.setRemarks(rs.getString(5));
				b2.setBnum(rs.getInt(6));
			}
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
		return b2;
	}
	
	public List<Books>findall()throws Exception{
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		List<Books> b=new ArrayList<Books>();
		String sql="select * from Book;";
		
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			rs=pst.executeQuery();
			while(rs.next()) {
				Books b1=new Books();
				b1.setBid(rs.getString(1));
				b1.setBname(rs.getString(2));
				b1.setAuthor(rs.getString(3));
				b1.setPrice(rs.getString(4));
				b1.setRemarks(rs.getString(5));
				b1.setBnum(rs.getInt(6));
				b.add(b1);
			}
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
		return b;
	}
public void deleteUser(String username)throws Exception {
		
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String sql="delete from log where username=? and type='普通用户'";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, username);
			int n=pst.executeUpdate();
			if(n==0)throw new Exception("删除用户失败");
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
	}

public List<Message> ShowAll() throws Exception {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		List<Message> messagelist = new ArrayList<Message>();
		con = DbConn.getDBconnect();
		
		pst=con.prepareStatement("select *from messageboard");
		rs = pst.executeQuery();
		while(rs.next())
		{
			Message message = new Message();
		
			message.setMessage(rs.getString(1));
			message.setTime(rs.getString(2));
			messagelist.add(message);
		}
		DbConn.closeDB(con, pst, rs);
		return messagelist;
	}

	//保存用户留言
	public boolean Write(Message message) throws Exception {
		// TODO Auto-generated method stub
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		boolean f = true ;
		try{
			con = DbConn.getDBconnect();
			pst = con.prepareStatement("insert into messageboard(message,time) values(?,?)");
			pst.setString(1, message.getMessage());
			pst.setString(2, message.getTime());
			int rownum = pst.executeUpdate();
			if(rownum==0)
			{
				f = false;
				
				System.out.print("Error!");
				
			}
			else{
				f =true;
				return f;
				
				}
			
		}catch(Exception e)
		{
			
		}finally{
			DbConn.closeDB(con, pst, rs);
			
		}
		return false;
	}
}
