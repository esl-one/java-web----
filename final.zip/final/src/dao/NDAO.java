package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import beans.Books;
import beans.Borrow;
import db.DbConn;

public class NDAO {
	private int num1;
	private int num;
	public int getN() {
		return num;
	}

	public int getNum() {
		return num1;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String findBook(String username)throws Exception{
		
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String bname="";
		String sql="select bname from borrow  where username=?;";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, username);
			rs=pst.executeQuery();
			while(rs.next()) {
				bname=rs.getString("bname");
			}
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
		return bname;
	}
	
	
	public void addborrow(Borrow b)throws Exception{
		
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String sql="insert into borrow values(?,?)";
		String sql2 = "update book set bnum=bnum-1 where bname=?";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, b.getUsername());
			pst.setString(2, b.getBname());
			int n=pst.executeUpdate();
			if(n==0)throw new Exception("借书失败");
			
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
			Connection con2=null;
			PreparedStatement pst2=null;
			ResultSet rs2=null;
			//String sql2 = "update book set bnum=(?-1) where bname=?";
			//System.out.println(getN());
			try{
				//System.out.println(getN());
				con2=DbConn.getDBconnect();
				pst2=con2.prepareStatement(sql2);
				//pst2.setInt(1,getN());
				pst2.setString(1, b.getBname());
				int n2=pst2.executeUpdate();
				//System.out.println(getN());
				if(n2==0)throw new Exception("借书失败");
			}catch(Exception e) {
				e.getStackTrace();
			}finally {
				DbConn.closeDB(con2, pst2, rs2);
			}
			
		} 
		
		
		
	}
public void deleteUser(String username,String bname)throws Exception {
		
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String sql="delete from borrow where bname=? and username=?;";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, bname);
			pst.setString(2, username);
			int n=pst.executeUpdate();
			if(n==0)throw new Exception("还书失败");
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
		
		Connection con2=null;
		PreparedStatement pst2=null;
		ResultSet rs2=null;
		String sql2 = "update book set bnum=bnum+1 where bname=?";
		try{
			con2=DbConn.getDBconnect();
			pst2=con2.prepareStatement(sql2);
			pst2.setString(1, bname);
			int n2=pst2.executeUpdate();
			if(n2==0)throw new Exception("借书失败");
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con2, pst2, rs2);
		}
	}

	public boolean Isborrow(String username)throws Exception{
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String sql="select count(*) as num from borrow where username=?";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, username);
			rs=pst.executeQuery();
			if(rs.next()) {
				setNum(rs.getInt("num"));
			}
			
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);	
		}
		if(getNum()>7) { return false;}
		else return true;
	}
	
public boolean check(String bname,String username)throws Exception{
		
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String sql="select *from borrow where bname=? and username=?;";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, bname);
			pst.setString(2, username);
			rs=pst.executeQuery();
			if(rs.next()) {
				
			return true;
				
			}
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
		return false;
	}

public boolean check2(String bname)throws Exception{
	
	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	String sql="select bnum from book where bname=?";
	try {
		con=DbConn.getDBconnect();
		pst=con.prepareStatement(sql);
		pst.setString(1, bname);
		rs=pst.executeQuery();
		//Books b = new Books();
		//System.out.println(b.getBnum());
		if(rs.next()) {
		this.num1=rs.getInt("bnum");
		if(this.num1>0)
		return true;
			
		}
	}catch(Exception e) {
		e.getStackTrace();
	}finally {
		DbConn.closeDB(con, pst, rs);
	}
	return false;
}
	
	public List<Borrow>findall(String username)throws Exception{
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		List<Borrow> b=new ArrayList<Borrow>();
		String sql="select * from borrow where username=?;";
		
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, username);
			rs=pst.executeQuery();
			while(rs.next()) {
				Borrow b1=new Borrow();
				b1.setUsername(rs.getString(1));
				b1.setBname(rs.getString(2));
				
				b.add(b1);
			}
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
		return b;
	}
	

	
	public boolean checkb(String bname)throws Exception{
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String sql="select *from Book where bname=?;";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, bname);
			rs=pst.executeQuery();
			if(rs.next()) {
				
			return true;
				
			}
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
		return false;
	}
	public boolean checkb2(String bname)throws Exception{
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String sql="select *from borrow where bname=?;";
		try {
			con=DbConn.getDBconnect();
			pst=con.prepareStatement(sql);
			pst.setString(1, bname);
			rs=pst.executeQuery();
			if(rs.next()) {
				
			return true;
				
			}
		}catch(Exception e) {
			e.getStackTrace();
		}finally {
			DbConn.closeDB(con, pst, rs);
		}
		return false;
	}
}
