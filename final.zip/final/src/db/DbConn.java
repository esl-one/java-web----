package db;
import java.sql.*;
public class DbConn {
	
	private static String driver = "com.mysql.jdbc.Driver";
	private static String username="root";
	private static String pwd="yy29360301";
	public static Connection getDBconnect(){
		
		String url = "jdbc:mysql://localhost:3306/final?useUnicode = true&characterEncoding = UTF-8";
		try{
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url,username,pwd);
			return con;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
		
	}
	public static void closeDB(Connection con,PreparedStatement pst,ResultSet rs){
		
		try{
			if(rs!=null)rs.close();
			if(pst!=null)pst.close();
			if(con!=null)con.close();
			
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
}
