package md5;
import java.security.*;
import sun.misc.*;
public class MD5_USE {
//	public static void main(String[] args){
//		System.out.println(MD5("abc"));
//	}
	public  String MD5(String oldStr){
		byte[] oldBytes = oldStr.getBytes();
		MessageDigest md;
		try{
			md = MessageDigest.getInstance("Md5");
			byte[] newBytes = md.digest(oldBytes);
			BASE64Encoder encoder = new BASE64Encoder();
			String newStr = encoder.encode(newBytes);
			return newStr;
			}catch(NoSuchAlgorithmException e){
				return null;
			}
	}
}
