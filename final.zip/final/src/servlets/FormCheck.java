package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.User;
import dao.Dao;
import md5.MD5_USE;

/**
 * Servlet implementation class FormCheck
 */
//@WebServlet("/FormCheck")
public class FormCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormCheck() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		request.setCharacterEncoding("UTF-8");
		String userid=request.getParameter("userid");
		char u[]=userid.toCharArray();
		if(u[0]<'A'||(u[0]>'Z'&&u[0]<'a')||u[0]>'z'){
			out.println("用户名必须以字母开头，后跟字母或数字");
		}		
		if(u.length<5){
			out.println("长度至少六位");
		}
		else{
		for(int i=1;i<u.length;i++){
			if(u[i]<48||(u[i]>57&&u[i]<64)||(u[i]>90&&u[i]<97)||u[i]>122){
				out.println("用户名无效");
			}
		}	
		if("a23333".equals(userid)){
			out.println("此用户名已注册");
		}
		else{
			String userpwd=request.getParameter("userpwd");
			String userpwd_1=request.getParameter("userpwd_1");
			if(!"".equals(userpwd) && !"".equals(userpwd_1)){
				char []p=userpwd.toCharArray();
				int flag=1;
				if(p.length<5||p.length>9){
					out.println("密码长度在6~10位");
				}
				else{
					for(int i=0;i<p.length;i++){
						if(p[i]<'0'||p[i]>'9'){
							out.println("密码必须是数字");
							flag=0;
							break;
						}
					}
				if(userpwd.equals(userpwd_1)&&flag==1)
					{
					request.setCharacterEncoding("UTF-8");
					response.setContentType("text/html,charset=utf-8");
					//response.getWriter().append("Served at: ").append(request.getContextPath());
					//String username=request.getParameter("userid");
					//String passwordold=request.getParameter("userpwd");
					String type=request.getParameter("type");
					User u1=new User();
					Dao d = new Dao();
					MD5_USE m = new MD5_USE();
					String password = m.MD5(userpwd);
					u1.setUserpwd(password);
					u1.setUsername(userid);
					u1.setType(type);
					try {
						d.addUser(u1);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					request.getRequestDispatcher("success1.jsp").forward(request, response);
					}
				else if(flag==1){
					out.println("两次密码不同，请重新输入!");		
				}
				
			  }	
		    }	
         }
	   }
	}
}


