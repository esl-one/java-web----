package servlets;

//import java.awt.List;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

import beans.Books;
import dao.Dao;

/**
 * Servlet implementation class ListUser
 */
@WebServlet("/ListUser")
public class ListUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		int pageNo = 1;
		int pageSize = 5;
		String strPageNo = request.getParameter("pageNo");
		if(strPageNo != null){
			pageNo = Integer.parseInt(strPageNo);
		}
		Dao d = new Dao();
		try{
			List<Books> bookslist = d.listBooks(pageNo);
			request.setAttribute("bookslist", bookslist);
			Integer pageCount = new Integer(Dao.getPageCount());
			//request.setAttribute("pageSize", pageSize);
			request.setAttribute("pageCount", pageCount);
			request.setAttribute("pageNo", pageNo);
			RequestDispatcher rd = request.getRequestDispatcher("booklist.jsp");
			rd.forward(request,response);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
