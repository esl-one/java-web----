package servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import beans.User;
/**
 * Servlet implementation class Logcheck
 */
//@WebServlet("/Logcheck")
public class Logcheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Logcheck() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		request.setCharacterEncoding("UTF-8");
		String info = "";
		
		//RequestDispatcher rd = request.getRequestDispatcher("/Login.jsp");
		//rd.forward(request,response);
		//request.setCharacterEncoding("utf-8");
		String username=request.getParameter("username");
		HttpSession session = request.getSession();
		String usercheckcode = request.getParameter("checkcode");
		String servercheckcode = (String)session.getAttribute("checkCode");
		session.setAttribute("username", username);
		String userpwd=request.getParameter("userpwd");
		String type=request.getParameter("type");
		User u=new User();
		try {
			if(!servercheckcode.equalsIgnoreCase(usercheckcode)){
				info = "验证码不正确，请重新输入";	
				request.setAttribute("info",info);
				request.getRequestDispatcher("Login.jsp").forward(request, response);
			}
			else {
			boolean f=u.yanzheng(username, userpwd,type);
			if(f==true&&type.equals("普通用户")) {
				request.getRequestDispatcher("nomal.jsp").forward(request, response);
			}
			else if(f==true&&type.equals("管理员")){
				request.getRequestDispatcher("admin.jsp").forward(request, response);
			}
			else {
				info = "账号或密码错误不正确，请重新输入";	
				request.setAttribute("info",info);
				request.getRequestDispatcher("Login.jsp").forward(request, response);
			}
			
			
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
