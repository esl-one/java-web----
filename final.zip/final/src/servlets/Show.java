package servlets;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.Message;
import dao.MDAO;

/**
 * Servlet implementation class Show
 */
//@WebServlet("/Show")
public class Show extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Show() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		String board = request.getParameter("message");           //获取用户留言的信息
		Date Now = new Date();                                      //获取当前时间
		SimpleDateFormat gtime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
		String time = (String)gtime.format(Now);// 将时间转换为字符串型
		Message Message = new Message(board,time);     //创建用户留言对象
		boolean f = false;                  //用于判断留言是否保存成功
		String info ="";                 //留言结果
		List<Message> MessageList = new ArrayList<Message>();        //所有留言数组
		try{
			MDAO WDAO = new MDAO();     //创建MessageDAO对象，用于保存留言
			f = WDAO.Write(Message);            //将留言写入数据库保存
			if(f==true)                            //如果留言成功
			{
				info ="编写公告成功！";
				MDAO SDAO = new MDAO();       //创建MessageDAO对象，用于显示所有留言
				MessageList = SDAO.ShowAll();          //获取所有留言及其相关信息
			}
			else
			{
				info="抱歉，编写公告失败！";
			}
		}catch(Exception e)
		{
			info ="出现异常！";
		}
		
		request.setAttribute("info",info);
		request.setAttribute("MessageList",MessageList);
		request.getRequestDispatcher("/show.jsp").forward(request, response);
		}
	}


